from django.conf.urls import url
from django.contrib import admin
from django.conf import settings
from django.conf.urls import include
from django.views.static import serve

from django.contrib.staticfiles.urls import staticfiles_urlpatterns



urlpatterns = [
    url(r'admin/', admin.site.urls),
    url(r'^app/', include('app.urls')),
    url(r'^accounts/', include('allauth.urls')),

]
if settings.DEBUG:
   urlpatterns +=[
        url(r'^media/(?P<path>.*)$',serve,{
            'document_root':settings.MEDIA_ROOT,
       }),
    ]

urlpatterns += staticfiles_urlpatterns()

