from django.conf.urls import url
from django.contrib import admin
from django.conf import settings
from django.conf.urls import include
from django.views.static import serve

from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from app import views

app_name='app'



urlpatterns = [
    url(r'admin/', admin.site.urls),
    url(r'^$',views.index),

    url(r'^contact/$', views.contact, name='contact'),
    url(r'^about/$', views.about, name='about'),
    url(r'^help/$', views.help, name='help'),
    url(r'^appointment/$',views.appointment, name='appointment'),
    url(r'^vaccine_for_you$', views.vaccine_for_you, name='vaccine_for_you'),
    url(r'^app/vaccine_for_you/output$', views.output, name= 'output'),
    url(r'^add$', views.add),


]


urlpatterns += staticfiles_urlpatterns()
