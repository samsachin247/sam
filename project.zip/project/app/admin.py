from django.contrib import admin
from django.forms import TextInput, Textarea

from .models import *

class AdminHelp(admin.ModelAdmin):
    list_display = ['name',
                         'mobile', 'comment']



admin.site.register(Help,AdminHelp)


