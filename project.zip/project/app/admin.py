from django.contrib import admin


from .models import Product
from .models import Regi
from .models import Help
class AdminProduct(admin.ModelAdmin):
    list_display = ['p_name',
                   'rate','image','description','qnty']
class AdminRegi(admin.ModelAdmin):
    list_display = ['name','mobile','psd']

class AdminHelp(admin.ModelAdmin):
    list_display = ['name',
                        'email', 'mobile', 'comment']



admin.site.register(Product,AdminProduct)
admin.site.register(Regi,AdminRegi)
admin.site.register(Help,AdminHelp)

