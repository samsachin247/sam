from django import forms
from .models import *
from django import forms

class RegiForm(forms.Form):
    name = forms.CharField(
                            widget=forms.TextInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder': 'Enter Your Name'

                                }
                            )
                        )
    mobile = forms.CharField(
                            widget=forms.TextInput(
                                attrs={
                                     'class': 'form-control',
                                     'placeholder': 'Enter Your Mobile Number'

                                }
                            )
                        )

    psd = forms.CharField(
                            widget=forms.PasswordInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder': 'Enter Your Password'

                                }
                            )
                        )

class HelpForm(forms.Form):
    name = forms.CharField(
                            widget=forms.TextInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder': 'Your Name...'

                                }
                            )
                        )
    email = forms.CharField(required=False,
                            widget=forms.TextInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder': 'Your Email...'

                                  }
                            )

                         )
    mobile = forms.IntegerField(required=False,
                            widget=forms.NumberInput(
                                 attrs={
                                     'class': 'form-control',
                                     'placeholder': 'Your Mobile...(optional)'

                                   }
                            )

                           )
    comment = forms.CharField(
                            widget=forms.Textarea(
                                attrs={
                                     'class': 'form-control',
                                     'placeholder': 'Your Comment...'

                                }
                            )
                        )

class LoginForm(forms.Form):
    mobile=forms.CharField()
    psd=forms.CharField(widget=forms.PasswordInput())



