from django import forms
from .models import *
from django import forms
from django.forms import TextInput, Textarea


class HelpForm(forms.Form):
    name = forms.CharField(
                            widget=forms.TextInput(
                                attrs={
                                    'class': 'form-control',
                                    'placeholder': 'Your Name...'

                                }
                            )
                        )

    mobile = forms.IntegerField(required=False,
                            widget=forms.NumberInput(
                                 attrs={
                                     'class': 'form-control',
                                     'placeholder': 'Your Mobile...(optional)'

                                   }
                            )

                           )
    comment = forms.CharField(
                            widget=forms.Textarea(
                                attrs={
                                     'class': 'form-control',
                                     'placeholder': 'Your Comment...'

                                }
                            )
                        )



