from __future__ import unicode_literals
from django.db import models
from django import forms
from django.conf import settings

class Help(models.Model):
    name= models.CharField(max_length=20)
    mobile = models.CharField(max_length=10, blank=True,null=True)
    comment = models.TextField(max_length=200)


    def __str__(self):
        return self.name





