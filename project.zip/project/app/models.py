from __future__ import unicode_literals
from django.db import models
from django import forms
from django.conf import settings




class Product(models.Model):
    p_name= models.CharField(max_length=20)
    rate= models.IntegerField(blank=True)
    image= models.ImageField(upload_to='images')
    description = models.CharField(max_length=400)
    qnty = models.CharField(max_length=10,null=True)


    def __str__(self):
        return self.p_name


class Regi(models.Model):
    name= models.CharField(max_length=20)
    mobile= models.CharField(max_length=10,unique=True)
    psd= models.CharField(max_length=20)

    def __str__(self):
        return self.name

class Help(models.Model):
    name= models.CharField(max_length=20)
    email= models.EmailField(blank=True,null=True)
    mobile = models.CharField(max_length=10, blank=True,null=True)
    comment = models.TextField(max_length=200)


    def __str__(self):
        return self.name



