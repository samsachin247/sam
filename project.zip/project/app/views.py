from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponseRedirect,HttpResponse
from django.urls import reverse
from django.contrib import messages
from .models import *
from .forms import RegiForm,LoginForm,HelpForm


import datetime


def index(request):
    pro = Product.objects.all()
    return render(request, 'home.html' ,{'pro' : pro})

def details(request, eid="0"):
    pro = Product.objects.get(pk=eid)
    return render(request,'detail.html',{'pro' : pro})

def regi(request):
    if request.method=='POST':
        form=RegiForm(request.POST)
        if form.is_valid():
            name=request.POST.get('name','')
            mobile=request.POST.get('mobile', '')
            psd=request.POST.get('psd', '')



        regi=Regi(name=name,mobile=mobile,psd=psd)

        regi.save()
        messages.info(request, 'Your Registration has been successfully recorded...')

        return redirect(reverse('app:regi'))
    else:
        form=RegiForm()
        return render(request,'regi.html',{'form':form})

def login(request):

    if request.method=='POST':
        MyLoginForm=LoginForm(request.POST)
        if MyLoginForm.is_valid():

            mobile=MyLoginForm.cleaned_data['mobile']
            psd=MyLoginForm.cleaned_data['psd']
            dbmobile=Regi.objects.filter(mobile=mobile)
            dbpsd=Regi.objects.filter(psd=psd)


            if  dbmobile and dbpsd:
                pro = Regi.objects.all()
                return render(request, 'profile.html',{'pro':pro ,'db':dbmobile,'dbp': dbpsd})


            else:
                return render(request, 'failed.html')

        else:
            print(MyLoginForm.errors)
    else:
        form=LoginForm()
        return render(request,'login.html',{'form':form})



def add_to_cart(request, **kwargs):
    product =Product.objects.filter(id=kwargs.get('item_id', "")).first()


    # show confirmation message and redirect back to the same page
    messages.info(request, "item added to cart")
    return redirect(reverse('app:home'))

def contact(request):

    return render(request, 'contact.html')

def helpcenter(request):
    if request.method=='POST':
        form=HelpForm(request.POST)
        if form.is_valid():
            name=request.POST.get('name','')
            email = request.POST.get('email', '')
            mobile=request.POST.get('mobile', '')
            comment = request.POST.get('comment', '')

        help=Help(name=name,email=email,mobile=mobile,comment=comment)

        help.save()
        messages.info(request, 'Thanku for your Feedback or any Complaint,we will contact you very soon...')

        return redirect(reverse('app:helpcenter'))
    else:
        form=HelpForm()
        return render(request,'help.html',{'form':form})




def profile(request):
    user = request.user
    content = {'user': user}
    template = 'profile.html'
    return render(request, template, content)
