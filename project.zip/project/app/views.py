from __future__ import unicode_literals
from django.shortcuts import render,redirect,get_object_or_404
from django.shortcuts import render
from django.urls import reverse
from django.contrib import messages
from .models import *
from .forms import HelpForm
from django.http import HttpResponse


i= None

def vaccine_for_you(request):

        return render(request,'app/foru.html')
def output(request):
    val1= request.GET['t1']

    global i

    i=int(val1)


    z= request.GET['but']
    if z =='submit':
        return redirect(add)

def add(request):
    k= i
    if  k < 0:
        return render(request, 'app/9.html')
    elif k == 0:
        return render(request, 'app/10.html')


    elif k > 0 and k <= 2:

      return render(request, 'app/1.html')
    elif k > 2 and k <= 4:
        return render(request, 'app/2.html')
    elif k > 4 and k <= 5:
        return render(request, 'app/3.html')
    elif k > 5 and k <= 7:
        return render(request, 'app/4.html')
    elif k > 7 and k <= 12:
        return render(request, 'app/5.html')
    elif k > 12 and k <= 18:
        return render(request, 'app/6.html')
    elif k > 18 and k <= 24:
        return render(request, 'app/7.html')

    else:
        return render(request, 'app/8.html')





def index(request):
    return render(request, 'app/index.html')

def contact(request):

    return render(request, 'app/contact.html')

def about(request):

    return render(request, 'app/about.html')

def help(request):
    if request.method=='POST':
        form=HelpForm(request.POST)
        if form.is_valid():
            name=request.POST.get('name','')
            mobile=request.POST.get('mobile', '')
            comment = request.POST.get('comment', '')

        help=Help(name=name,mobile=mobile,comment=comment)

        help.save()
        messages.info(request, 'Thanku for your Feedback or any Complaint,we will contact you very soon...')

        return redirect(reverse('help'))
    else:
        form=HelpForm()
        return render(request,'app/help.html',{'form':form})

def appointment(request):
    return render(request, 'app/appointment.html')




