from  django.conf.urls import url,include
from django.contrib.auth.views import login
from app import views
app_name='app'

urlpatterns = [
    url(r'^$', views.index, name= 'index'),
    url(r'^adminapp/(?P<eid>\d+)/$', views.details, name='details'),
    url(r'^regi$', views.regi, name='regi'),
    url(r'^login/$', views.login, name='login'),
    url(r'^add-to-cart/(?P<item_id>\d+)/$', views.add_to_cart, name="add_to_cart"),
    url('^profile/$', views.profile, name='profile'),
    url(r'^contact/$', views.contact, name='contact'),
    url(r'^helpcenter/$', views.helpcenter, name='helpcenter'),

]
