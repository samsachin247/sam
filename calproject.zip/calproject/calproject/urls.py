from django.contrib import admin
from django.conf.urls import url
from django.conf.urls import include
from calapp import views

urlpatterns = [
    url('admin/', admin.site.urls),
    url(r'^$',views.input,name= 'input'),
    url(r'^calapp/output$', views.output, name= 'output'),
    url(r'^add$', views.add),
    url(r'^sub$', views.sub),

]
