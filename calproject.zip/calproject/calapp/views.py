from django.shortcuts import render,redirect
from django.http import HttpResponse

i= None
j= None

def input(request):
    return render(request,'calapp/add.html')

def output(request):
    val1= request.GET['t1']
    val2= request.GET['t2']
    global i
    global j
    i=int(val1)
    j=int(val2)

    z= request.GET['but']
    if z =='add':
        return redirect(add)
    if z=='sub':
        return redirect(sub)

def add(request):
    k= i+j
    data="addition of",i , "and" ,j , "is:", k
    return HttpResponse(data)

def sub(request):
    k= i-j
    data="Substraction of",i , "and" ,j , "is:", k
    return HttpResponse(data)


